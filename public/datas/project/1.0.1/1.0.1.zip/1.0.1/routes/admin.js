var express = require('express');
var router = express.Router();
var multer  = require('multer');
var fs = require('fs');
var unzip = require("unzip");
var request = require("request");
var wget = require('node-wget');
var upload = multer({ dest: 'upload/' });




/* GET home page. */
router.get('/', function(req, res) {
    if(!req.session.username){
        res.redirect('/sign/login');
        return;
    }

    res.render('admin', {username: req.session.username});
});


/* Upload Route */
router.post('/file-upload', upload.array('thumbnail', 5), function(req, res) {

    if(req.files.length < 1){
        res.redirect('/admin');
    }
    for (var i = 0; i < req.files.length; i++) {
        fs.rename(req.files[i].path, "upload/" + req.files[i].originalname, function(err) {
            if (err) {
                throw err;
            }
            console.log('done!');
        })
    }


    var timer = null;
    //unzip after's name
    var filesname = req.files[0].originalname.split('.')[0];
    //unzip file
    console.log('upload/' + req.files[0].originalname)
    fs.createReadStream('upload/' + req.files[0].originalname).pipe(unzip.Extract({path: 'upload/'}));
    var emptyDir = function(fileUrl){
        var files = fs.readdirSync(fileUrl);//读取该文件夹
        files.forEach(function(file){
            var stats = fs.statSync(fileUrl + '/' + file);
            if(stats.isDirectory()){
                emptyDir(fileUrl + '/' + file);
            }else{
                fs.unlinkSync(fileUrl + '/' + file);
                console.log("删除文件" + fileUrl + '/' + file + "成功");
            }
        });
    }
    var rmEmptyDir = function(fileUrl){
        var files = fs.readdirSync(fileUrl);
        if(files.length > 0){
            var tempFile = 0;
            files.forEach(function(fileName)
            {
                tempFile++;
                rmEmptyDir(fileUrl + '/' + fileName);
            });
            if(tempFile == files.length){//删除母文件夹下的所有字空文件夹后，将母文件夹也删除
                fs.rmdirSync(fileUrl);
                console.log('删除空文件夹' + fileUrl + '成功');
            }
        }else{
            fs.rmdirSync(fileUrl);
            console.log('删除空文件夹' + fileUrl + '成功');
        }
    }
    timer = setInterval(function(){
        if(fs.existsSync('upload/' + req.files[0].originalname.split('.')[0])){
            clearInterval(timer);
            //move file
            
            fs.readdir('upload/' + req.files[0].originalname.split('.')[0], function(err, files){
                if(err){
                    console.log('error:\n' + err);
                    return;
                }
                console.log(files)
                //判断多个目录是否存在
                movefile(0)

                function movefile(i){
                    fs.exists('/home/robosense_bak/' + files[i], function(exists){
                        if(exists){
                            //清空要更新的目录
                            emptyDir('/home/robosense_bak/' + files[i]);
                            rmEmptyDir('/home/robosense_bak/' + files[i]);

                            fs.rename('upload/' + req.files[0].originalname.split('.')[0] + '/' + files[i], '/home/robosense_bak/' + files[i], function(err) {
                                if (err) { 
                                    throw err;
                                }
                                console.log('done!');
                            })
                        }else{
                            fs.rename('upload/' + req.files[0].originalname.split('.')[0] + '/' + files[i], '/home/robosense_bak/' + files[i], function(err) {
                                if (err) { 
                                    throw err;
                                }
                                console.log('done!');
                            })
                        }
                        i++;
                        if(files[i]){
                            movefile(i);
                        }else{       
                            emptyDir('upload/');
                            rmEmptyDir('upload/');
                        }
                    })
                }
                res.render('uploaderror', {msg: '更新成功！', redirect: '/admin'});
                
            });
        }
    }, 1000);
});


//清空文件夹
var emptyDir = function(fileUrl){
    var files = fs.readdirSync(fileUrl);//读取该文件夹
    files.forEach(function(file){
        var stats = fs.statSync(fileUrl + '/' + file);
        if(stats.isDirectory()){
            emptyDir(fileUrl + '/' + file);
        }else{
            fs.unlinkSync(fileUrl+'/'+file);
            console.log("删除文件" + fileUrl + '/' + file + "成功");
        }
    });
}
var rmEmptyDir = function(fileUrl){
    var files = fs.readdirSync(fileUrl);
    if(files.length > 0){
        var tempFile = 0;
        files.forEach(function(fileName)
        {
            tempFile++;
            rmEmptyDir(fileUrl+'/'+fileName);
        });
        if(tempFile == files.length){//删除母文件夹下的所有字空文件夹后，将母文件夹也删除
            fs.rmdirSync(fileUrl);
            console.log('删除空文件夹' + fileUrl + '成功');
        }
    }else{
        fs.rmdirSync(fileUrl);
        console.log('删除空文件夹' + fileUrl + '成功');
    }
}

//判断版本大小函数
function cpversion(old_version, new_version){
	var old_version_arr = old_version.split('.');	
	var new_version_arr = new_version.split('.');
	if(old_version_arr[0] < new_version_arr[0]){
		return true;
	}else if(old_version_arr[1] < new_version_arr[1]){
		return true;
	}else if(old_version_arr[2] < new_version_arr[2]){
		return true;
	}else{
		return false;
	}	
}

router.get('/updateproject', function(req, res){

    var timer = null;
    fs.readFile('./version.json', 'utf-8', function(err, data){
        if(err){
            res.json({code: -22, msg: '找不到更新的版本号'});
            return;
        }
        var local_version = data;

        request('http://120.25.154.37/datas/project/version.json', function(err, response, body){
            if(err){
                console.log(err);
                res.json({code: -1, msg: '更新失败，远程版本号获取不到'});
                return;
            }
            var last_version = body.replace('\n', '');

            //判断更新包版本是都与安装的一样，如果有高的版本，则自动更新
            if(cpversion(local_version, last_version) || true){

                var url = 'http://120.25.154.37/datas/project/' + last_version + '/' + last_version + '.zip';

                console.log(url);

                // 下载最新安装包到本地
                wget({
                    url: url,
                    dest: 'upload/', 
                },function (error, response, body){
                    if (error || body.indexOf('404') != -1){
                        res.json({code: -1, msg: '下载更新包失败', test: url});
                        return;
                    }
                    //解压最新安装包
                    fs.createReadStream('upload/' + last_version + '.zip').pipe(unzip.Extract({path: 'upload/'}));
                    console.log(11111)
                    timer = setInterval(function(){
                    console.log(2222)
                        if(fs.existsSync('upload/' + last_version)){
                            clearInterval(timer);
                            //move file
                            
                            fs.readdir('upload/' + last_version, function(err, files){
                                if(err){
                                    console.log('error:\n' + err);
                                    return;
                                }

                    console.log(3333)
                                console.log(files)
                                //判断多个目录是否存在
                                movefile(0)

                                function movefile(i){
                                    fs.exists('/home/robosense/' + files[i], function(exists){

                    console.log(4444)
                                        if(exists){
                                            //清空要更新的目录
                                            emptyDir('/home/robosense/' + files[i]);
                                            rmEmptyDir('/home/robosense/' + files[i]);

                                            fs.rename('upload/' + last_version + '/' + files[i], '/home/robosense/' + files[i], function(err) {
                                                if (err) { 
                                                    throw err;
                                                }
                                                console.log('done!');
                                            })
                                        }else{
                                            fs.rename('upload/' + last_version + '/' + files[i], '/home/robosense/' + files[i], function(err) {
                                                if (err) { 
                                                    throw err;
                                                }
                                                console.log('done!');
                                            })
                                        }
                                        i++;
                                        if(files[i]){
                                            movefile(i);
                                        }else{       
                                            emptyDir('upload/');
                                            // rmEmptyDir('upload/');
                                            //更新版本号
                                            fs.readFile('./version.json', 'utf-8', function(err, data){
                                                fs.writeFile('./version.json', last_version, function(err){
                                                    if(err){
                                                        console.log('失败')
                                                    }
                                                });
                                            })
                                        }
                                    })
                                }
                                res.json({code: 0, msg: '更新成功！'});
                                
                            });
                        }
                    }, 1000);
                });            
            };
        })
    })
})

module.exports = router;


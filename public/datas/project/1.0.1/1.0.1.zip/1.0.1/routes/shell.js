var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res) {
    if(!req.session.username){
        res.redirect('/sign/login');
        return;
    }

    res.render('shell', {username: req.session.username});
});


module.exports = router;


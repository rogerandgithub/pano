var express = require('express');
var router = express.Router();
var multer  = require('multer');
var fs = require('fs');
var http = require('http');
var multiparty = require('multiparty');
var upload = multer({ dest: 'upload/' });
var exec = require('child_process').exec;
var spawn = require('child_process').spawn;

exec('sudo node /home/robosense/routes/tty.js', function(error, stdout, stderr){
    console.log(stdout);
});

//sqing
//

/* GET home page. */
router.get('/', function(req, res) {
    if(!req.session.username){
        res.redirect('/sign/login');
        return;
    }


    res.render('algorithm', {username: req.session.username});
});

router.get('/test', function(req, res){
    exec('export tte=hahahahah&&echo $test', function(error, stdout, stderr){
        console.log(stdout);
        res.send(stdout);
    });
})

/* open */
router.get('/open', function(req, res){
    // exec('script -f out.txt', function(error, stdout, stderr){
    //     if (error){
    //         console.log(error)
    //         res.json({code: -1, msg: '找不到roslanuch'});
    //         return;
    //     }
        // exec('. /home/ubuntu/robosense/run/devel/setup.sh && roslaunch /home/ubuntu/robosense/run/src/perception/launch/no_map.launch', function (error, stdout, stderr) {
        //     if (error){
        //         console.log(error)
        //         res.json({code: -1, msg: '打开失败'});
        //         return;
        //     }
        //     console.log('Child Process STDOUT: ' + stdout);
        //     res.json({code: 0, msg: '打开成功'})
        // });
    // })
    // var child = exec('ls -l');
console.log(1111111111111111111111111);
    var child = exec('. /home/ubuntu/robosense/run/devel/setup.sh && roslaunch /home/ubuntu/robosense/run/src/perception/launch/test_record.launch');

    child.stdout.on('data', function(data) {
        console.log('stdout1111: ' + data);
    });
    child.stderr.on('data', function(data) {
        console.log('stdout2222: ' + data);
    });
    child.on('close', function(code) {
        console.log('closing code: ' + code);
    });
    res.json({code: 0, msg: '打开成功'})
    // var ls = spawn('. /home/ubuntu/robosense/run/devel/setup.sh');

    // ls.stdout.on('data', function(data){
    //   console.log('11111111111',data.toString());
    // });

    // ls.stderr.on('data', function(data){
    //   console.log('22222222',data);
    // });

    // ls.on('close', function(code){
    //   console.log('3333333333',code.toString());
    // });
    exec('script -f out.txt && ls', function(error, stdout, stderr){
        if (error){
            console.log(error)
            res.json({code: -1, msg: '找不到roslanuch'});
            return;
        }
        // exec('', function(error, stdout, stderr){
        //     if (error){
        //         console.log(error)
        //         res.json({code: -2, msg: '打开失败'});
        //         return;
        //     }
        //     console.log('Child Process STDOUT: ' + stdout);
            res.json({code: 0, msg: '打开成功'})
        // });
    })
})

/* close */
router.get('/close', function(req, res){
    // exec('rosrun perception /home/ubuntu/robosense/run/src/perception/launch/no_map.launch', function (error, stdout, stderr) {
    //     if (error){
    //         res.json({code: -1, msg: '打开失败'});
    //         return;
    //     }
    //     console.log('Child Process STDOUT: ' + stdout);
    //     res.json({code: 0, msg: '打开成功'})
    // });
    res.json({code: 0, msg: '关闭成功'})
})



module.exports = router;

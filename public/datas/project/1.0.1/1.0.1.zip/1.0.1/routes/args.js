var express = require('express');
var router = express.Router();
var multer  = require('multer');
var fs = require('fs');
var multiparty = require('multiparty');
var upload = multer({ dest: 'upload/' });

/* GET home page. */
router.get('/', function(req, res) {
    if(!req.session.username){
        res.redirect('/sign/login');
        return;
    }

    res.render('args', {username: req.session.username});
});

/* Upload Route */
router.post('/file-upload', function(req, res) {

    var form = new multiparty.Form();
    form.parse(req, function(err, fields, files) {
        var len = 0;
        for(var i in files){
            len++;
        }
        if(len < 1){
            res.json({code: -1, msg: '上传文件为空，请重新上传'});
            return;
        }
        if(files['file1'][0].originalFilename != 'perception_args.xml'){
            res.json({code: -1, msg: '上传文件名错误，请重新上传！'});
            return;
        }

        //'/home/ubuntu/robosense/robosense_sdk_tx2/src/play_tool/rslidar/rslidar_pointcloud/data/calibration' is exits

        fs.exists('/home/ubuntu/robosense/args/', function(exists){
            if(!exists){
                fs.mkdir('/home/ubuntu/robosense/args/', function(err){
                    if(err){
                        console.log(err);
                    }
                    console.log('创建目录成功');
                    //move files
                    moveFile();
                })
            }else{
                moveFile();
            }

            function moveFile(){
                fs.exists('/home/ubuntu/robosense/args/perception_args.xml', function(exists){

                    if(exists){
                        fs.unlink('/home/ubuntu/robosense/args/perception_args.xml');
                    }
                    fs.rename(files['file1'][0].path, '/home/ubuntu/robosense/args/' + files['file1'][0].originalFilename, function(err) {
                        if (err) {
                            console.log(err);
                        }
                        console.log('done!');
                        res.json({code: 0, msg: '上传成功！'});
                    })
                })
            }
        })
    })
});

module.exports = router;


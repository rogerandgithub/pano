var express = require('express');
var router = express.Router();
var multer  = require('multer');
var fs = require('fs');
var unzip = require("unzip");
var multiparty = require('multiparty');
var upload = multer({ dest: 'upload/' });

/* GET home page. */
router.get('/', function(req, res) {
    if(!req.session.username){
        res.redirect('/sign/login');
        return;
    }

    res.render('map', {username: req.session.username});
});

/* Upload Route */
router.post('/file-upload', function(req, res) {
    var form = new multiparty.Form();
    form.parse(req, function(err, fields, files) {

        console.log(files)
        var len = 0;
        for(var i in files){
            len++;
        }

        if(len < 1){
            res.json({code: -1, msg: '上传文件不能为空'});
            return;
        }
        fs.rename(files['file1'][0].path, 'upload/' + files['file1'][0].originalFilename, function(err) {
            if (err) {
                console.log(err);
            }
            console.log('done!');
        })


        var timer = null;
        //unzip after's name
        // var filesname = req.files[0].originalname.split('.')[0];
        //unzip file
        fs.createReadStream('upload/' + files['file1'][0].originalFilename).pipe(unzip.Extract({path: 'upload/'}));
        var emptyDir = function(fileUrl){
            var files = fs.readdirSync(fileUrl);//读取该文件夹
            files.forEach(function(file){
                var stats = fs.statSync(fileUrl + '/' + file);
                if(stats.isDirectory()){
                    emptyDir(fileUrl + '/' + file);
                }else{
                    fs.unlinkSync(fileUrl + '/' + file);
                    console.log("删除文件" + fileUrl + '/' + file + "成功");
                }
            });
        }
        var rmEmptyDir = function(fileUrl){
            var files = fs.readdirSync(fileUrl);
            if(files.length > 0){
                var tempFile = 0;
                files.forEach(function(fileName)
                {
                    tempFile++;
                    rmEmptyDir(fileUrl + '/' + fileName);
                });
                if(tempFile == files.length){//删除母文件夹下的所有字空文件夹后，将母文件夹也删除
                    fs.rmdirSync(fileUrl);
                    console.log('删除空文件夹' + fileUrl + '成功');
                }
            }else{
                fs.rmdirSync(fileUrl);
                console.log('删除空文件夹' + fileUrl + '成功');
            }
        }
        fs.exists('/home/ubuntu/robosense/map/', function(exists){
            if(!exists){
                fs.mkdir('/home/ubuntu/robosense/map/', function(err){
                    if(err){
                        console.log(err);
                    }
                    console.log('创建目录成功');
                    //move files
                    moveFile();
                })
            }else{
                moveFile();
            }

            function moveFile(){
                fs.exists('/home/ubuntu/robosense/map/feature_map', function(exists){  
                    if(exists){
                        emptyDir('/home/ubuntu/robosense/map/feature_map');
                        rmEmptyDir('/home/ubuntu/robosense/map/feature_map');
                    }
                    timer = setInterval(function(){
                        if(fs.existsSync('upload/' + files['file1'][0].originalFilename.split('.')[0])){
                            clearInterval(timer);
                            //move file
                            fs.readdir('upload/' + files['file1'][0].originalFilename.split('.')[0], function(err, zipfiles){
                                if(err){
                                    console.log('error:\n' + err);
                                    return;
                                }
                                console.log(zipfiles)

                                if(zipfiles.length != 2){
                                    res.json({code: -1, msg: '压缩包里必须包含两个文件'})
                                    return;
                                }
                                var validate = ['feature_map', 'map.vtk']
                                for(var i in zipfiles){
                                    console.log(zipfiles[i])
                                    if(validate.indexOf(zipfiles[i]) == -1){
                                        res.json({code: -2, msg: '上传的压缩包里的两个文件名字不正确'});
                                        return;
                                    }
                                }

                                zipfiles.forEach(function(file){
                                    if(file == 'feature_map'){
                                        fs.rename('upload/' + files['file1'][0].originalFilename.split('.')[0] + '/' + file, '/home/ubuntu/robosense/map/feature_map', function(err) {
                                            if (err) {
                                                console.log(err);
                                            }
                                            console.log('done!');
                                        })
                                    }else if(file == 'map.vtk'){
                                        fs.exists('/home/ubuntu/robosense/map/map.vtk', function(exists){
                                            console.log('---------------------1', exists)
                                            if(exists){
                                                fs.unlink('/home/ubuntu/robosense/map/map.vtk');
                                            }
                                            fs.rename('upload/' + files['file1'][0].originalFilename.split('.')[0] + '/' + file, '/home/ubuntu/robosense/map/map.vtk', function(err) {
                                                if (err) {
                                                    console.log(err);
                                                }
                                                console.log('done!');
                                                emptyDir('upload/' + files['file1'][0].originalFilename.split('.')[0]);
                                                rmEmptyDir('upload/' + files['file1'][0].originalFilename.split('.')[0]);
                                                fs.unlink('upload/' + files['file1'][0].originalFilename);
                                            })
                                            
                                        })
                                    }
                                })

                                res.json({code: 0, msg: '上传成功！'})
                            });
                        }
                    }, 1000);

                })

            }
        })
    })
});

module.exports = router;


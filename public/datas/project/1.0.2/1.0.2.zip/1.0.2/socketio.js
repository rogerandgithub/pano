// socketio.js
var socketio = {};
var socket_io = require('socket.io');

// net
var express = require('express');
var router = express.Router();
var http = require('http');
// var net = require('net');
var fs = require('fs');
var exec = require('child_process').exec;


// net.createServer(function(socket){

//     socket.on('data', function(data){
//         pipedata = data;
//         console.log(data.toString())
//     });

//     socket.on('end', function(){
//         console.log('net disconnected');
//     });

// }).listen(5023, function(){
//     console.log('net server for text started on port 5023');
// });


//获取io
var socketIo;
socketio.getSocketio = function(server){
    socketIo = socket_io.listen(server);
    socketIo.sockets.on('connection', function(socket) {
        console.log('socketio 连接成功');

        //start algorithm
        socket.on('start algorithm', function(data){
            var child = exec('. /home/ubuntu/robosense/run/devel/setup.sh && roslaunch /home/ubuntu/robosense/run/src/robosense_sdk/launch/test_record.launch');

            socketIo.emit('start_algorithm_ok', '启动成功');
            child.stdout.on('data', function(data) {
                socketIo.emit('algorithmMsg', data.toString());
		if((data.toString()).indexOf('shutting down processing monitor complete') != -1){
            	    socketIo.emit('stop_algorithm_ok', '关闭成功');
		}
            });
            child.stderr.on('data', function(data) {
                socketIo.emit('algorithmErrMsg', data.toString());
            });
            child.on('close', function(code) {
                console.log('closing startcode1: ' + code);
            });
        })  
        //stop algorithm
        socket.on('stop algorithm', function(data){
            // var child = exec('. /home/ubuntu/robosense/run/devel/setup.sh && rosnode kill `rosnode list`');
            exec('sudo killall roslaunch');
            //socketIo.emit('stop_algorithm_ok', '关闭成功');

        })   
        socket.on('disconnect', function(){
            console.log('socket 断开');
        });
    });

};

//net
// net.createServer(function(netsocket){

//     netsocket.on('data', function(data){
//         console.log(data.toString())
//         socketIo.emit('chat message', data.toString());
//     });

//     netsocket.on('end', function(){
//         console.log('net disconnected');
//     });

// }).listen(5023, function(){
//     console.log('net server for text started on port 5023');
// });


module.exports = socketio;

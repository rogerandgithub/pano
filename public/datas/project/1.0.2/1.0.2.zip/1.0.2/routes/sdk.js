var express = require('express');
var router = express.Router();
var multer  = require('multer');
var fs = require('fs');
var upload = multer({ dest: 'upload/' });
var unzip = require("unzip");
var path = require('path');
var multiparty = require('multiparty');
var exec = require('child_process').exec;
var wifi = require('node-wifi');
var utils = require('./utils');
var http = require('http');
var wget = require('node-wget');
var wifi = require('node-wifi');
var request = require('request');



//wifi init
wifi.init({
    iface : null // network interface, choose a random wifi interface if set to null
});
router.get('/wifilist', function(req, res){
	var wifilist = [];
    //获取wifi列表
    wifi.scan(function(err, networks){
	    if (err){
	        console.log(err);
	    }else{
	        for(var i in networks){
	        	wifilist.push(networks[i].ssid)
	        }
	    }
	    exec('ping -c 1 120.25.154.37', function (error, stdout, stderr){
		var isnetwork;
		if(error){
	    		isnetwork = false;
		}else{
			isnetwork = true;
		}
		exec('aptitude show ros-kinetic-robosense-localization', function(error, stdout, stderr){
			if (error) {
	  			res.json({code: -1, msg: '更新失败，本地版本号获取不到', wifilist: []});
	  			return;
		  	}
		  	var index = stdout.indexOf('Version:');
		  	var local_version = stdout.substring(index + 9, index + 14);
		  	console.log(local_version)
		  	var noupdate = false;

		  	request('http://120.25.154.37/datas/sdk/localization/version.json', function(err,response,body){
		  		if(err){
		  			console.log('更新失败，远程版本号获取不到');
		  		}else{
		  			var last_version = body.replace('\n', '');
		  			console.log(last_version)
				  	//判断更新包版本是都与安装
				  	if(!cpversion(local_version, last_version)){
				  		noupdate = true;
				  	}
		  		}
	    			res.json({wifilist: wifilist, isnetwork: isnetwork, noupdate: noupdate})
			});
		});
	});
	});
})

//清空文件夹
var emptyDir = function(fileUrl){
    var files = fs.readdirSync(fileUrl);//读取该文件夹
    files.forEach(function(file){
        var stats = fs.statSync(fileUrl + '/' + file);
        if(stats.isDirectory()){
            emptyDir(fileUrl + '/' + file);
        }else{
            fs.unlinkSync(fileUrl+'/'+file);
            console.log("删除文件" + fileUrl + '/' + file + "成功");
        }
    });
}
var rmEmptyDir = function(fileUrl){
    var files = fs.readdirSync(fileUrl);
    if(files.length > 0){
        var tempFile = 0;
        files.forEach(function(fileName)
        {
            tempFile++;
            rmEmptyDir(fileUrl+'/'+fileName);
        });
        if(tempFile == files.length){//删除母文件夹下的所有字空文件夹后，将母文件夹也删除
            fs.rmdirSync(fileUrl);
            console.log('删除空文件夹' + fileUrl + '成功');
        }
    }else{
        fs.rmdirSync(fileUrl);
        console.log('删除空文件夹' + fileUrl + '成功');
    }
}


/* GET perception_sdk */
router.get('/perception', function(req, res) {
    res.render('perception');	
});


//check the networking
router.get('/check/networking', function(req, res){
	var sdkName = req.query.sdkname;
	utils.isnetwork(function(status, wifilist, network){
        var ssid = network[0] ? network[0].ssid : '';
	exec('aptitude show ros-kinetic-robosense-' + sdkName, function(error, stdout, stderr){
	    if (error) {
	  	res.json({code: -1, msg: '本地版本号获取不到', wifilist: wifilist, ssid: ssid, isnetwork: false, noupdate: false});
	  	return;
	    }
	    var index = stdout.indexOf('Version:');
	    var local_version = stdout.substring(index + 9, index + 14);
	    var noupdate = false;

    	    if(status){
		request('http://120.25.154.37/datas/sdk/' + sdkName + '/version.json', function(err,response,body){
		    if(err){
			console.log('远程版本号获取不到');
		    }else{
			var last_version = body.replace('\n', '');
			console.log(last_version)
			//判断更新包版本是都与安装
			if(!cpversion(local_version, last_version)){
			    noupdate = true;
			}
		    }
    		    res.json({code: 0, msg: 'The Internet is connected', wifilist: wifilist, ssid: ssid, isnetwork: true, noupdate: noupdate});
		})
    	    }else{
		if(wifilist.length){
		    exec('ping -c 1 120.25.154.37', function (error, stdout, stderr){
                        if(stdout.indexOf('1 received') != -1){
			    request('http://120.25.154.37/datas/sdk/' + sdkName + '/version.json', function(err,response,body){
			        if(err){
				    console.log('远程版本号获取不到');
				}else{
				    var last_version = body.replace('\n', '');
				    console.log(last_version)
				    //判断更新包版本是都与安装
				    if(!cpversion(local_version, last_version)){
				        noupdate = true;
				    }
			        }
    				res.json({code: 0, msg: 'The Internet is connected', wifilist: wifilist, ssid: ssid, isnetwork: true, noupdate: noupdate});
   			    });
			}else{
	    		    res.json({code: -1, msg: 'Can\'t connect the Internet', wifilist: wifilist,ssid: ssid, isnetwork: false, noupdate: noupdate});
		        }
		    })
    		}else{
	    	    res.json({code: -1, msg: 'Can\'t connect the Internet', wifilist: wifilist, ssid: ssid, isnetwork: false, noupdate: noupdate});
	        }
	    }
	});
    });
});


//判断版本大小函数
function cpversion(old_version, new_version){
	var old_version_arr = old_version.split('.');	
	var new_version_arr = new_version.split('.');
	if(old_version_arr[0] < new_version_arr[0]){
		return true;
	}else if(old_version_arr[1] < new_version_arr[1]){
		return true;
	}else if(old_version_arr[2] < new_version_arr[2]){
		return true;
	}else{
		return false;
	}	
}

/* GET perception_sdk */
router.get('/localization', function(req, res) {
    res.render('localization');	
});


/* 自动下载更新sdk包 */
router.get('/autoupdate', function(req, res){
	//要更新的sdk
	var sdkName = req.query.sdkName;

	exec('aptitude show ros-kinetic-robosense-' + sdkName, function(error, stdout, stderr){
		if (error) {
  			res.json({code: -1, msg: '更新失败，本地版本号获取不到'});
  			return;
	  	}
	  	var index = stdout.indexOf('Version:');
	  	var local_version = stdout.substring(index + 9, index + 14);
	  	console.log('_____本地版本：', local_version);

	  	request('http://120.25.154.37/datas/sdk/' + sdkName + '/version.json', function(err,response,body){
	  		if(err){
	  			console.log(err);
	  			res.json({code: -1, msg: '更新失败，远程版本号获取不到'});
	  			return;
	  		}
  			var last_version = body.replace('\n', '');

		  	//判断更新包版本是都与安装的一样，如果有高的版本，则自动更新
		  	if(cpversion(local_version, last_version) || true){

		  		var packetName = 'ros-kinetic-robosense-' + sdkName + '_' + last_version + '-0xenial_arm64.deb';

		  		var url = 'http://120.25.154.37/datas/sdk/' + sdkName + '/' + last_version + '/' + packetName;

		  		console.log(url);

		  		// 下载最新安装包到本地
		  		wget({
			        url: url,
			        dest: path.join(__dirname, '../public/download/'), 
			    },function (error, response, body){
			        if (error || body.indexOf('404') != -1){
			        	res.json({code: -1, msg: '下载更新包失败', test: url});
			        	return;
			        }
			        //安装最新安装包
			        var install_cmd = 'dpkg -i ' + path.join(__dirname, '../public/download') + '/' + packetName;

			        console.log(install_cmd);

	                exec(install_cmd, function (error, stdout, stderr) {
					  	if (error){
						    res.json({code: -1, msg: '安装失败'});
						    return;
					  	}
					  	console.log('Child Process STDOUT: ' + stdout);
					  	// emptyDir(path.join(__dirname, '../public/download/'));
     //                    rmEmptyDir(path.join(__dirname, '../public/download/'));
					  	res.json({code: 0, msg: '更新成功'})
					});
			    });            
		    };
  		})
	})
});


/* Update  localization_sdk*/
router.post('/update', function(req, res){
    var form = new multiparty.Form();
    form.parse(req, function(err, fields, files) {
    	var name = req.query.name;
    	console.log(files)
        var len = 0;
        for(var i in files){
            len++;
        }
		if(len < 1){
	    	res.json({code: -1, msg: '上传文件为空，请重新上传'});
	    	return;
	    }
		//判断文件是定位还是感知
		if(files['file1'][0].originalFilename.indexOf(name == 'localization' ? 'robosense-localization' : 'robosense-perception') == -1){
	    	res.json({code: -1, msg: '上传文件名错误，请重新上传！'});
	        return;
		}
		//move debfs.exists('/home/ubuntu/robosense/deb/', function(exists){
	    fs.exists('/home/ubuntu/robosense/deb/', function(exists){
	        if(!exists){
	            fs.mkdir('/home/ubuntu/robosense/deb/', function(err){
	                if(err){
	                    console.log(err);
	                }
	                console.log('创建目录成功');
	                //move files
	                moveFile();
	            })
	        }else{
	            moveFile();
	        }

	        function moveFile(){
				fs.rename(files['file1'][0].path, '/home/ubuntu/robosense/deb/' + files['file1'][0].originalFilename, function(err){
					console.log(11111)
					if (err) {
			            console.log(err);
			        }
			        console.log('move' + files['file1'][0].originalFilename + 'done!');
			        //uninstall
				    exec('dpkg -r ros-kinetic-' + name, function (error, stdout, stderr) {
					  	if (error) {
						    console.log(error.stack);
						    console.log('Error code: ' + error.code);
						    res.json({code: -1, msg: '卸载失败'})
						    return;
					  	}
					  	console.log('Child Process STDOUT: ' + stdout);
					  	//install
				  		exec('dpkg -i ' + '/home/ubuntu/robosense/deb/' + files['file1'][0].originalFilename, function (error, stdout, stderr) {
						  	if (error){
							    console.log(error.stack);
							    console.log('Error code: ' + error.code);
							    res.json({code: -1, msg: '安装失败'})
							    return;
						  	}
						  	console.log('Child Process STDOUT: ' + stdout);
						  	//添加环境变量
						  	exec('echo /opt/ros/kinetic/lib/ > /etc/ld.so.conf.d/robo-localization.conf && ldconfig', function(error, stdout, stderr){
						  		if (error) {
								    console.log(error.stack);
								    console.log('Error code: ' + error.code);
							  	}
							  	console.log('Child Process STDOUT: ' + stdout);
                                emptyDir('upload/');
                                rmEmptyDir('upload/');
							    // rmEmptyDir('upload/');
							    res.json({code: 0, msg: '安装成功'});
						  	})
					  	});
					});
				})
	        }
	    })
    })
})


/* 连接wifi */
router.post('/connectwifi', function(req, res){
	var wifiname = req.body.wifiname;
	var wifipassword = req.body.wifipassword;
	if(!wifiname || !wifipassword){
		res.json({code: -1, msg: 'wifi账号活密码不能为空'});
		return;
	}

	wifi.connect({ssid : wifiname, password : wifipassword}, function(err) {
	    if(err){
	        res.json({code: -2, msg: 'wifi密码不正确'});
	        return;
	    }
	    exec('sudo route add -host 192.168.1.1 dev wlan0', function(error, stdout, stderr){
		console.log(error)
		console.log(stderr)
	    	exec('sudo route add -host 192.168.1.254 dev wlan0', function(error, stdout, stderr){
		    console.log(error)
		    console.log(stderr)
	    	})
	    })
	    res.json({code: 0, msg: '连接成功'});
	});

})

/* openwifi */
router.get('/openwifi', function(req, res){
	exec('sudo nmcli radio wifi on', function(error, stdout, stderr){
		if(error){
			res.json({code: -1, msg: '打开Wifi失败'});
			return;
		}
		var wifilist = [];
	    //获取wifi列表
	    setTimeout(function(){
		    wifi.scan(function(err, networks){
			    if (err){
			        console.log(err);
			    }else{
			       	console.log(networks)
			        for(var i in networks){
			        	wifilist.push(networks[i].ssid)
			        }
			    }
			    res.json({code: 0, msg: 'ok', wifilist: wifilist})
			});
	    }, 3000)
	})
})

/* 断开wifi */
router.post('/disconnectwifi', function(req, res){

	wifi.disconnect(function(err) {
	    if(err){
	        res.json({code: -2, msg: err});
	        return;
	    }
	    res.json({code: 0, msg: '断开成功'});
	});

})



module.exports = router;


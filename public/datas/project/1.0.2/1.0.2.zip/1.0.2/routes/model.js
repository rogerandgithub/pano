var express = require('express');
var router = express.Router();
var multer  = require('multer');
var fs = require('fs');
var multiparty = require('multiparty');
var upload = multer({ dest: 'upload/' });


/* GET model page. */
router.get('/', function(req, res) {
    res.render('model');	
});

/* GET classification page. */
router.get('/classification', function(req, res) {
    //if(!req.session.username){
        //res.redirect('/sign/login');
       // return;
    //}

    res.render('classification');
});


/* GET ground_detection page. */
router.get('/ground_detection', function(req, res) {
    //if(!req.session.username){
        //res.redirect('/sign/login');
        //return;
    //}

    res.render('ground_detection');
});


/* Upload Route */
router.post('/file-upload', upload.array('thumbnail', 5), function(req, res) {
    var form = new multiparty.Form();
    form.parse(req, function(err, fields, files) {
        
        var len = 0;
        for(var i in files){
            len++;
        }

        if(len < 1){
            res.json({code: -1, msg: '上传文件不能为空'});
            return;
        }


        //'/home/ubuntu/robosense/robosense_sdk_tx2/src/play_tool/rslidar/rslidar_pointcloud/data/calibration' is exits
        fs.exists('/home/ubuntu/robosense/model/', function(exists){
            if(!exists){
                fs.mkdir('/home/ubuntu/robosense/model/', function(err){
                    if(err){
                        console.log(err);
                    }
                    console.log('创建目录成功');
                    //move files
                    moveFile();
                })
            }else{
                moveFile();
            }
            res.json({code: 0, msg: '上传成功'});

        })            
        function moveFile(){
            for (var i in files) {
                fs.exists('/home/ubuntu/robosense/model/' + files[i][0].originalFilename, function(exists){
                    if(exists){
                        fs.unlink('/home/ubuntu/robosense/model/' + files[i][0].originalFilename);
                    }
                    fs.rename(files[i][0].path, '/home/ubuntu/robosense/calibration/' + files[i][0].originalFilename, function(err) {
                        if (err) {
                            console.log(err);
                        }
                        console.log('done!');
                    })
                })
            }
        }
    })

});

// router.post('/update/ground_detection', upload.array('thumbnail', 5), function(req, res) {

//     if(req.files.length < 1){
//         res.redirect('/model/ground_detection');
//     }

//     if(req.files[0].originalname != 'ground_detection_model.xml'){
//         res.render('uploaderror', {msg: '上传文件名错误，请重新上传！', redirect: '/model/ground_detection'});
//         return;
//     }

//     //'/home/ubuntu/robosense/robosense_sdk_tx2/src/play_tool/rslidar/rslidar_pointcloud/data/calibration' is exits

//     fs.exists('/home/ubuntu/robosense/model/', function(exists){
//         if(!exists){
//             fs.mkdir('/home/ubuntu/robosense/model/', function(err){
//                 if(err){
//                     console.log(err);
//                 }
//                 console.log('创建目录成功');
//                 //move files
//                 moveFile();
//             })
//         }else{
//             moveFile();
//         }

//         function moveFile(){
//             fs.exists('/home/ubuntu/robosense/model/ground_detection_model.xml', function(exists){
//                 if(exists){
//                     fs.unlink('/home/ubuntu/robosense/model/ground_detection_model.xml');
//                 }
//                 fs.rename(req.files[0].path, '/home/ubuntu/robosense/model/' + req.files[0].originalname, function(err) {
//                     if (err) {
//                         console.log(err);
//                     }
//                     console.log('done!');
//                     res.render('uploaderror', {msg: '上传成功！', redirect: '/model/ground_detection'});
//                 })
//             })

//         }
//     })

// });


/* Get edit model file */
router.get('/files', function(req, res){
    res.render('modelfiles');	
})


/* Get edit model file data*/
router.get('/filesdata', function(req, res){

    fs.readdir('/home/ubuntu/robosense/model/', function(err, files){
        if(err){
            res.json({code: -1, msg: '没有model文件夹'});
            return;
        }
        res.json({code: 0, msg: 'ok', files: files});
    })

})


/*  model file delete*/
router.post('/deletefiles', function(req, res){
    var files = JSON.parse(req.body.files);

    deletefiles(0);

    function deletefiles(i){
        fs.unlink('/home/ubuntu/robosense/model/' + files[i], function (error){
            if (error) {
                console.log(error);
            }
            if(files[i+1]){
                deletefiles(i+1)
            }else{
                res.json({code: 0, msg: 'ok'})
            }
        });
    }
})

module.exports = router;


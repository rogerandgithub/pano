var exec = require('child_process').exec;
var wifi = require('node-wifi');

//wifi init
wifi.init({
    iface : null // network interface, choose a random wifi interface if set to null
});

exports.isnetwork = function(callback){

    //if network is Ok, scan the wifi list
    wifi.scan(function(err, networks){
        var wifilist = [];
        for(var i in networks){
            wifilist.push(networks[i].ssid)
        }
        wifi.getCurrentConnections(function(err, network){
            exec('ping -c 1 120.25.154.37', function (error, stdout, stderr){
                if(stdout.indexOf('1 received') != -1){
                    if (err){
                        callback(true,[],network);
                    }else{
                        callback(true,wifilist,network)
                    }
                }else{
		    	callback(false,wifilist,network);
		};
            });
        })
    })
};

var tty = require('tty.js');

/* TTY CONFIG */
var app = tty.createServer({
  	shell: 'bash',
  	// users: {
  	//   sqing: 'sqing0304'
  	// },
  	port: 8000
});


/* ROUTER */
app.get('/foo', function(req, res, next) {
  res.send('bar');
});

app.listen();


var express = require('express');
var router = express.Router();
var multer  = require('multer');
var fs = require('fs');
var http = require('http');
var multiparty = require('multiparty');
var upload = multer({ dest: 'upload/' });


//  登录页面渲染
router.get('/login', function(req, res){
    res.render('login');
});

//  登录请求
router.post('/login', function(req, res){

    var username = req.body.username;
    var password = req.body.password;

    if(!username || !password){
        res.json({code: -1, msg: '用户名或密码不能为空'});
        return;
    }

    if(username == 'admin' && password == '6a50d2c2511252edeb442c9725d928bf'){
        req.session.username = username;
        res.json({code: 0, msg: '登录成功'});
    }else if(username == 'user' && password == 'ee11cbb19052e40b07aac0ca060c23ee'){
        req.session.username = username;
        res.json({code: 0, msg: '登录成功'});
    }else{
        res.json({code: -2, msg: '登录失败，账号或密码不正确'});
    }
});

//  注销
router.get('/logout', function(req, res){

    req.session.username = undefined;
    res.redirect('/sign/login');

});

module.exports = router;


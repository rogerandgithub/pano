var express = require('express');
var router = express.Router();
var multer  = require('multer');
var fs = require('fs');
var http = require('http');
var multiparty = require('multiparty');
var upload = multer({ dest: 'upload/' });


/* GET home page. */
router.get('/', function(req, res) {
    res.render('static');
});

/* Upload Route */
router.post('/file-upload', function(req, res) {

    var form = new multiparty.Form();
    form.parse(req, function(err, fields, files) {
        console.log(files)
        var len = 0;
        for(var i in files){
            len++;
        }

        if(len < 1){
        	res.json({code: -1, msg: '上传文件不能为空'});
            return;
        }

        if(len != 3){
            res.json({code: -2, msg: '必须上传三个文件'});
            return;
        }

        var filesname = ['curves.csv', 'angle.csv', 'ChannelNum.csv'];
        for(var i in files){
            if(filesname.indexOf(files[i][0].originalFilename) == -1){
                res.json({code: -2, msg: '上传文件名错误，请重新上传！'});
                return;
            }
        }

        fs.exists('/home/ubuntu/robosense/calibration/', function(exists){
            if(!exists){
                console.log(111111)
                fs.mkdir('/home/ubuntu/robosense/calibration/', function(err){
                    if(err){
                        console.log(err);
                    }
                    console.log('创建目录成功');
                    //move files
                    moveFile();
                })
            }else{
                //move files
                moveFile();
            }
            res.json({code: 0, msg: '上传成功'});
        })

        function moveFile(){
            for (var i in files) {
                fs.rename(files[i][0].path, '/home/ubuntu/robosense/calibration/' + files[i][0].originalFilename, function(err) {
                    if (err) {
                        console.log(err);
                    }
                    console.log('done!');
                })
            }
        }
    })

});

module.exports = router;


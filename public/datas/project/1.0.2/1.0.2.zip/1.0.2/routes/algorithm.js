var express = require('express');
var router = express.Router();
var multer  = require('multer');
var fs = require('fs');
var http = require('http');
var multiparty = require('multiparty');
var upload = multer({ dest: 'upload/' });
var exec = require('child_process').exec;
var spawn = require('child_process').spawn;

exec('sudo node /home/robosense/routes/tty.js', function(error, stdout, stderr){
    console.log(stdout);
}); 

/* GET home page. */
router.get('/', function(req, res) {
    exec('. /home/robosense/installCaffeJTX1/maxPerformance.sh && sudo nmcli radio wifi on', function(error, stdout, stderr){
	res.render('algorithm');
    });
});

/* open */
router.get('/open', function(req, res){
    var child = exec('. /home/ubuntu/robosense/run/devel/setup.sh && roslaunch /home/ubuntu/robosense/run/src/robosense_sdk/launch/test_record.launch');

    child.stdout.on('data', function(data) {
        console.log('stdout1111: ' + data);
    });
    child.stderr.on('data', function(data) {
        console.log('stdout2222: ' + data);
    });
    child.on('close', function(code) {
        console.log('closing code: ' + code);
    });
    res.json({code: 0, msg: '打开成功'})
    exec('script -f out.txt && ls', function(error, stdout, stderr){
        if (error){
            console.log(error)
            res.json({code: -1, msg: '找不到roslanuch'});
            return;
        }
        res.json({code: 0, msg: '打开成功'})
    })
})

/* close */
router.get('/close', function(req, res){
    res.json({code: 0, msg: '关闭成功'})
})



module.exports = router;

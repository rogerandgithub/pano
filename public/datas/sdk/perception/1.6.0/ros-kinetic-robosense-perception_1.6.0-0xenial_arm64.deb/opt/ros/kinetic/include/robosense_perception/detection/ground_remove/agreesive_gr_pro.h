/**
 *****************************************************************************
 * COPYRIGHT STATEMENT
 * Copyright (c) 2018, Robosense Co.,Ltd. - www.robosense.ai
 * All Rights Reserved.
 *
 * You can not use, copy or spread without official authorization.
 *****************************************************************************
 *
 * Author: Robosense Perception Group
 * Version: 1.6.0
 * Date: 2018.2
 *
 * DESCRIPTION
 *
 * Robosense ground remove module.
 *
 */
#ifndef ROBOSENSE_DETECTION_AGREESIVE_GR_PRO_H
#define ROBOSENSE_DETECTION_AGREESIVE_GR_PRO_H

#include "common/data_type/robo_types.h"

namespace Robosense{
    namespace Detection{
        template <typename PointT>
        class AgreesiveGrPro{
        public:
            typedef pcl::PointCloud<PointT> PointCloud;
            typedef typename PointCloud::Ptr PointCloudPtr;
            typedef typename PointCloud::ConstPtr PointCloudConstPtr;

            AgreesiveGrPro(const RoboLidarConfig &lidar_config);
            ~AgreesiveGrPro(){}

            /**
             * @brief ground remove use agreesive method
             * @param[in] in_cloud_ptr input cloud for ground remove
             * @param[out] objects output objects
             */
            void agreesiveGrPro(const PointCloudConstPtr in_cloud_ptr,
                                PointCloudPtr obstacle_cloud_ptr);

            /**
             * @brief get ground points
             * @param[in,out] ground_cloud_ptr ground point cloud of ground
             */
            void getAgreesiveProGroundPts(PointCloudPtr ground_cloud_ptr);

            void setAgreesiveProParam(const Range2D& range = Range2D(-50.,50.,-50.,50),const float& grid_size = 1.f);
            void setAgreesiveProConstrainParam(const float& thre = 0.2,const float& abs_height_thre = 0.6);
        protected:
            inline int ptx2grid(const float& val);
            inline int pty2grid(const float& val);
            inline int rowcol2grid(const int& row,const int& col);
            inline bool isNanPt(const PointT& pt);
            bool isReasonableRange2D(const Range2D& range);
            Range2D range_;
            float grid_size_;
            float thre_,abs_thre_;
            int rows_,cols_;
            PointCloudPtr ground_cloud_ptr_;
        private:
            RoboLidarConfig lidar_config_;
        };
    }
}

#endif //ROBOSENSE_DETECTION_AGREESIVE_GR_PRO_H

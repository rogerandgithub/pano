/**
 *****************************************************************************
 * COPYRIGHT STATEMENT
 * Copyright (c) 2018, Robosense Co.,Ltd. - www.robosense.ai
 * All Rights Reserved.
 *
 * You can not use, copy or spread without official authorization.
 *****************************************************************************
 *
 * Author: Robosense Perception Group
 * Version: 1.6.0
 * Date: 2018.2
 *
 * DESCRIPTION
 *
 * Robosense ground remove module.
 *
 */
#ifndef ROBOSENSE_DETECTION_LINEFIT_GR_PRO_H
#define ROBOSENSE_DETECTION_LINEFIT_GR_PRO_H

#include "common/data_type/robo_types.h"
#include <pcl/sample_consensus/ransac.h>
#include <pcl/sample_consensus/sac_model_plane.h>

namespace Robosense{
    namespace Detection{
        template <typename PointT>
        class LinefitGrPro{
        public:
            typedef pcl::PointCloud<PointT> PointCloud;
            typedef typename PointCloud::Ptr PointCloudPtr;
            typedef typename PointCloud::ConstPtr PointCloudConstPtr;
            typedef pcl::SampleConsensusModelPlane<PointT> SampleConsensusModelPlane;
            typedef typename SampleConsensusModelPlane::Ptr SampleConsensusModelPlanePtr;
            typedef pcl::RandomSampleConsensus<PointT> RandomSampleConsensus;

            LinefitGrPro(const RoboLidarConfig &lidar_config);
            ~LinefitGrPro(){}

            /**
             * @brief ground remove use linefit method
             * @param[in] in_cloud_ptr input cloud for ground remove
             * @param[out] objects output objects
             */
            void linefitGrPro(const PointCloudConstPtr in_cloud_ptr, PointCloudPtr obstacle_cloud_ptr);
            /**
             * @brief get ground points
             * @param[in,out] ground_cloud_ptr ground point cloud of ground
             */
            void getLinefitProGroundPts(PointCloudPtr ground_cloud_ptr);

            void setLinefitProConstrainParams(const float& height_thre = 0.2,const float& angle_thre = 5.);
            void setLinefitProParams(const float& range = 50.,const float& angle_step = 0.5,const float& range_step = 0.2);
            void setLinefitProGroundPlaneParams(const Range2D& range = Range2D(-15.,15.,-10.,10.));
            void setLinefitProGroundPlaneConstrainParam(const float& thre_ = 0.2, const float& abs_thre = 1.f);
        protected:
            inline int ptx2grid(const float& val);
            inline int pty2grid(const float& val);
            inline int rowcol2grid(const int& row,const int& col);
            inline int gdptx2grid(const float& val);
            inline int gdpty2grid(const float& val);
            inline int gdrowcol2grid(const int& row,const int& col);
            inline int gdpptx2grid(const float& val);
            inline int gdppty2grid(const float& val);
            inline int gdprowcol2grid(const int& row,const int& col);
            inline float comRange(const PointT& pt);
            inline float comBeta(const PointT& pt);
            inline float pt2plane(const PointT& pt,const Eigen::VectorXf& plane_model);
            inline float pt2pt(const PointT& pt1, const PointT& pt2);
            inline float locateInPlane(const PointT& pt,const Eigen::VectorXf& plane_model);
            inline bool isNanPt(const PointT& pt);
            bool isReasonableRange2D(const Range2D& range);
            float range_,rad_step_,range_step_;
            int rows_,cols_;
            Range2D ground_plane_range_;
            float pg_range_;
            int cg_rows_,cg_cols_,pg_rows_,pg_cols_;
            float cg_size_,pg_ran_step_,pg_rad_step_;
            float height_thre_,rad_thre_;
            float ground_plane_thre_;
            float abs_thre_;
            PointCloudPtr ground_cloud_ptr_;
        private:
          RoboLidarConfig lidar_config_;
        };
    }
}
#endif //ROBOSENSE_DETECTION_LINEFIT_GR_PRO_H

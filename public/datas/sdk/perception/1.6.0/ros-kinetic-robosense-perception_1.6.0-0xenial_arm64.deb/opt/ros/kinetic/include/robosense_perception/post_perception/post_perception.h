
/**
 *****************************************************************************
 * COPYRIGHT STATEMENT
 * Copyright (c) 2018, Robosense Co.,Ltd. - www.robosense.ai
 * All Rights Reserved.
 *
 * You can not use, copy or spread without official authorization.
 *****************************************************************************
 *
 * Author: Robosense Perception Group
 * Version: 1.0.0
 * Date: 2017.10
 *
 * DESCRIPTION
 *
 * Robosense post-perception module, including classification and multi-objects tracking.
 *
 */


#ifndef ROBOSENSE_PERCEPTION
#define ROBOSENSE_PERCEPTION

#include "post_perception/classification/classifier0.h"
#include "post_perception/classification/classifier1.h"
#include "post_perception/tracker/tracker.h"

namespace Robosense{

/**
 * @todo tobe complished ...
 * @ingroup postprocessing
 */
class PostPerception{



};




}

#endif

/**
 * @brief postprocessing module
 * @defgroup postprocessing
 */


/**
 *****************************************************************************
 * COPYRIGHT STATEMENT
 * Copyright (c) 2018, Robosense Co.,Ltd. - www.robosense.ai
 * All Rights Reserved.
 *
 * You can not use, copy or spread without official authorization.
 *****************************************************************************
 *
 * Author: Robosense Perception Group
 * Version: 1.6.0
 * Date: 2018.1
 *
 * DESCRIPTION
 *
 * Robosense built-in data structs type definition module.
 *
 */

#ifndef ROBOSENSE_TYPES_H
#define ROBOSENSE_TYPES_H

#include "common/data_type/basic_types.h"
#include "common/data_type/box_type.h"
#include "common/data_type/cluster_type.h"
#include "common/data_type/obj_type.h"
#include "common/data_type/target_type.h"
#include "common/data_type/perception_type.h"
#include "common/data_type/configuration_type.h"

namespace Robosense
{

typedef RoboCluster<pcl::PointXYZINormal> NormalRoboCluster;
typedef RoboPerceptron<pcl::PointXYZINormal> NormalRoboPerceptron;

typedef RoboCluster<pcl::PointXYZI> PtsRoboCluster;
typedef RoboPerceptron<pcl::PointXYZI> PtsRoboPerceptron;

}



#endif //ROBOSENSE_TYPES_H


/**
 *****************************************************************************
 * COPYRIGHT STATEMENT
 * Copyright (c) 2018, Robosense Co.,Ltd. - www.robosense.ai
 * All Rights Reserved.
 *
 * You can not use, copy or spread without official authorization.
 *****************************************************************************
 *
 * Author: Robosense Perception Group
 * Version: 1.6.0
 * Date: 2018.1
 *
 * DESCRIPTION
 *
 * Robosense box module, for object bounding box calculation.
 *
 */

#ifndef ROBOSENSE_BOXER_H
#define ROBOSENSE_BOXER_H

#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include "common/data_type/robo_types.h"

namespace Robosense
{


/**
 * @brief find anchor of a boundingbox
 * anchor is the corner idx has the lest distance to origin of lidar coordinate
 * @param[in] box
 * @return
 */
int findBoxAnchor(const BoundingBox &box);

/**
 * @brief calculate box area
 * @param[in] box input boundingbox
 * @return box area
 */
float getBoxArea(const BoundingBox &box);

/**
 * @brief calculate box volume
 * @param[in] box input boundingbox
 * @return box volume
 */
float getBoxVolume(const BoundingBox &box);

/**
 * @brief rectify box for those nearly horizontal to axis.
 * @param[in] box input original box
 * @param[in] ang_thd the tilt angel thd within which need to rectify
 * @param[in] len_thd the length thd of box length within which need to rectify
 * @return rectified box
 */
BoundingBox rectifyBox(const BoundingBox &box, float ang_thd, float len_thd);

/**
 * @brief rotate boundingbox
 * only work for xy plane
 * @param[in] box input boundingbox
 * @param[in] angle input rotate angle in radian
 * @return rotated boundingbox
 */
BoundingBox rotateBox2D(const BoundingBox &box, float angle);

/**
 * @brief rotate boundingbox with a given center point
 * @param[in] box input boundingbox
 * @param[in] angle input rotate angle in radian
 * @param[in] rot_center rotate center
 * @return
 */
BoundingBox rotateBox2DwithCenter(const BoundingBox &box, float angle, Point3f rot_center);

/**
 * @brief scale boundingbox
 * @param[in] box input boundingbox
 * @param[in] scale input scale value
 * @return scaled boundingbox
 */
BoundingBox scaleBox(const BoundingBox &box, float scale);

/**
* @brief translate boundingbox
* @param[in] box input boundingbox
* @param[in] t move vector
* @return translated boundingbox
*/
BoundingBox transBox(const BoundingBox &box, Point3f t);

/**
* @brief resize boundingbox based on anchor
 * means the anchor shoud not moved after resizing the box
* @param[in] box input boundingbox
* @param[in] new_size input new size value
* @return resized boundingbox
*/
BoundingBox resizeBox(const BoundingBox &box, Point3f new_size);

/**
 * @brief makeing a boundingbox according given info
 * @param[in] size box size
 * @param[in] center box center
 * @param[in] angle box direction
 * @return generated box
 */
BoundingBox makeBox(Point3f size, Point3f center, float angle);

/**
 * @brief semantic box infer
 * @param box input original geometry bbox
 * @param usr_config some geometry params
 * @return infered semantic box
 */
BoundingBox boxInferByGeo(const BoundingBox &box, const ObjectLimit &obj_limit, const RoboLidarConfig& lidarConfig);

/**
 * @brief calculate attributes for a box when given corners.
 * @param box
 */
void calcSubAttribute(BoundingBox& box);


/**
 * @brief calculate bounding-box for pointcloud cluster
 */

template <typename PointT>
class BoundingBoxCalculator {

public:

  typedef pcl::PointCloud<PointT> PointCloud;
  typedef typename PointCloud::Ptr PointCloudPtr;
  typedef typename PointCloud::ConstPtr PointCloudConstPtr;

  /**
   * @brief constructor
   * @param[in] grid_size grid size used to estimate the box edge
   * @param[in] theta angular unit used to estimate the main direction of box
   * @param[in] min_num_thd points num less than it will use the calcSimpleBox()
   */
  BoundingBoxCalculator(float grid_size = 0.1, float theta = M_PI / 360., int min_num_thd = 20);

  /**
   * @brief reset the parameters
   * @param[in] grid_size grid size used to estimate the box edge
   * @param[in] theta angular unit used to estimate the main direction of box
   * @param[in] min_num_thd points num less than it will use the calcSimpleBox()
   */
  void setParams(float grid_size = 0.1, float theta = M_PI / 360., int min_num_thd = 20);

  /**
   * @brief calculate boundingbox by coordinate aligned, fast
   */

  BoundingBox calcSimpleBox(PointCloudConstPtr segment);

  /**
   * @brief calculate boundingbox by object aligned, slow but accurate
   */
  BoundingBox calcBoundingBox(PointCloudConstPtr segment);


private:

  Point3f getSegmentCenter(PointCloudConstPtr segment);

  float grid_size_, grid_size_inv_;
  float theta_;
  int min_num_thd_;
  std::vector<float> tabCos_, tabSin_;
};


/**
 * @todo TODO: some new fundamentally supporting functions will be added in the future ...
 */


}

#endif
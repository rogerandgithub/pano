/**
 *****************************************************************************
 * COPYRIGHT STATEMENT
 * Copyright (c) 2018, Robosense Co.,Ltd. - www.robosense.ai
 * All Rights Reserved.
 *
 * You can not use, copy or spread without official authorization.
 *****************************************************************************
 *
 * Author: Robosense Perception Group
 * Version: 1.6.0
 * Date: 2018.2
 *
 * DESCRIPTION
 *
 * Robosense cluster module.
 *
 */
#ifndef ROBOSENSE_DETECTION_CART_CLUSTER_PRO_H
#define ROBOSENSE_DETECTION_CART_CLUSTER_PRO_H

#include "common/data_type/robo_types.h"
#include <opencv2/opencv.hpp>

namespace Robosense{
    namespace Detection{
        template <typename PointT>
        class CartClusterPro{
        public:
            typedef pcl::PointCloud<PointT> PointCloud;
            typedef typename PointCloud::Ptr PointCloudPtr;
            typedef typename PointCloud::ConstPtr PointCloudConstPtr;

            CartClusterPro(const RoboLidarConfig &lidar_config, const RoboUsrConfig &usr_config);
            ~CartClusterPro(){}

            /**
             * @brief cluster
             * @param[in] in_cloud_ptr input cloud for clustering
             * @param[out] objects output objects
             */
            void cartClusterPro(const PointCloudConstPtr in_cloud_ptr, std::vector<PointCloudPtr>& objects);

            /**
             * @brief set cluster params
             * @param[in] range,grid_size,clutser_z,growth_z,growth_step,dilate_size params set for clustering
             */
            void setCartClusterParams(const Range2D& range = Range2D(-50.,50.,-50.,50.),const float& grid_size = 0.2f,
                                      const float& clutser_z = 2.f,const float& growth_z = 5.f,
                                      const float& growth_step = 0.25f,const int& dilate_size = 1);

            /**
             * @brief set cluster restrict params
             * @param[in] restrict_pts params set for clustering restrict size
             */
            void setRestrictPts(const int& restrict_pts = 3);

            void setUserDefineCartClusterProXYScan(Eigen::Vector2f (*pf)(const PointT&) = NULL);
            void setUserDefineCartClusterProGrowthZScan(float (*pf)(const PointT&) = NULL);
            void setUserDefineCartClusterProGrowthXYScanScan(Eigen::Vector2f (*pf)(const PointT&) = NULL);

        protected:
            void setConditionMat();
            Eigen::Vector2f (*computeCartClusterProXYScan_)(const PointT& pt) = NULL;
            Eigen::Vector2f computeCartClusterProXYScan(const PointT& pt);

            float (*computeCartClusterProGrowthZScan_)(const PointT& pt) = NULL;
            float computeCartClusterProGrowthZScan(const PointT& pt);

            Eigen::Vector2f (*computeCartClusterProGrowthXYScan_)(const PointT& pt) = NULL;
            Eigen::Vector2f computeCartClusterProGrowthXYScan(const PointT& pt);

            inline int ptx2grid(const float& val);
            inline int pty2grid(const float& val);
            inline int ptz2grid(const float& val);
            inline void cluster(const cv::Mat& bin_mat,cv::Mat& label_mat);
            inline void growth(const cv::Mat& label_mat,
                               const std::vector<cv::Mat>& growth_bin_mat,
                               std::vector<cv::Mat>& growth_label_mat);
            inline bool isNanPt(const PointT& pt);
            bool isReasonableRange2D(const Range2D& range);
            Range2D range_;
            float grid_size_,growth_z_,growth_step_,cluster_z_;
            int rows_,cols_,growth_slice_,dilate_size_;
            std::set<std::pair<int,int> > merge_;
            int restrict_min_pts_;

          float hori_angle_res_, vert_angle_res_;

            cv::Mat scan_x_mat_,scan_y_mat_,scan_growth_z_mat_,scan_growth_x_mat_,scan_growth_y_mat_, seed_top_mat_, grow_down_mat_;

        private:
          RoboLidarConfig lidar_config_;
          RoboUsrConfig usr_config_;
          float hori_res_, vert_res_;

        };
    }
}

#endif //ROBOSENSE_DETECTION_CART_CLUSTER_PRO_H

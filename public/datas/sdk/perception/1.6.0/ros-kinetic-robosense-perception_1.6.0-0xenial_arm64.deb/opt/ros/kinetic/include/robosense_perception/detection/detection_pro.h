/**
 *****************************************************************************
 * COPYRIGHT STATEMENT
 * Copyright (c) 2018, Robosense Co.,Ltd. - www.robosense.ai
 * All Rights Reserved.
 *
 * You can not use, copy or spread without official authorization.
 *****************************************************************************
 *
 * Author: Robosense Perception Group
 * Version: 1.6.0
 * Date: 2018.2
 *
 * DESCRIPTION
 *
 * Robosense detection module.
 *
 */
#ifndef ROBOSENSE_DETECTION_DETECTION_PRO_H
#define ROBOSENSE_DETECTION_DETECTION_PRO_H

#include "detection/ground_remove/linefit_gr_pro.h"
#include "detection/ground_remove/agreesive_gr_pro.h"
#include "detection/ground_remove/classify_gr_pro.h"
#include "detection/ground_remove/gp_gr_pro.h"
#include "detection/cluster/cart_cluster_pro.h"


namespace Robosense{
    namespace Detection{
        template <typename PointT>
        class DetectionPro:public LinefitGrPro<PointT>,public AgreesiveGrPro<PointT>,
                           public ClassifyGrPro<PointT>,public GpGrPro<PointT>,public CartClusterPro<PointT>{
        public:
            typedef pcl::PointCloud<PointT> PointCloud;
            typedef typename PointCloud::Ptr PointCloudPtr;
            typedef typename PointCloud::ConstPtr PointCloudConstPtr;

            DetectionPro(const RoboLidarConfig &lidar_config, const RoboUsrConfig &usr_config);
            ~DetectionPro(){}

            /**
             * @brief object detection
             * @param[in] in_cloud_ptr input cloud for detection
             * @param[out] clusters,obstacle_cloud_ptr output of detection
             */
            void detectionPro(const PointCloudConstPtr in_cloud_ptr, std::vector<PointCloudPtr>& clusters, PointCloudPtr obstacle_cloud_ptr);

            /**
             * @brief get ground points
             * @param[in,out] ground_cloud_ptr the result ground cloud of this function
             */
            void getGroundPts(PointCloudPtr ground_cloud_ptr);

            /**
             * @brief set ground remove mode
             * @param[in] mode the mode set to use different method to remove ground points
             */
            void setGrMode(const int& mode = 0);
        protected:
            int gr_mode_;

        private:
        };
    }
}

#endif //ROBOSENSE_DETECTION_DETECTION_PRO_H

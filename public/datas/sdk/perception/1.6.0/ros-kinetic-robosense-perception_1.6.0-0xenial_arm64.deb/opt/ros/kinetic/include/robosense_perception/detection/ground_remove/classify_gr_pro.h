/**
 *****************************************************************************
 * COPYRIGHT STATEMENT
 * Copyright (c) 2018, Robosense Co.,Ltd. - www.robosense.ai
 * All Rights Reserved.
 *
 * You can not use, copy or spread without official authorization.
 *****************************************************************************
 *
 * Author: Robosense Perception Group
 * Version: 1.6.0
 * Date: 2018.2
 *
 * DESCRIPTION
 *
 * Robosense ground remove module.
 *
 */
#ifndef ROBOSENSE_DETECTION_CLASSIFY_GR_PRO_H
#define ROBOSENSE_DETECTION_CLASSIFY_GR_PRO_H

#include "common/data_type/robo_types.h"

namespace Robosense{
    namespace Detection{
        template <typename PointT>
        class ClassifyGrPro{
        public:
            typedef pcl::PointCloud<PointT> PointCloud;
            typedef typename PointCloud::Ptr PointCloudPtr;
            typedef typename PointCloud::ConstPtr PointCloudConstPtr;

            ClassifyGrPro(const RoboLidarConfig &lidar_config);
            ~ClassifyGrPro(){}

            /**
             * @brief ground remove use classify method
             * @param[in] in_cloud_ptr input cloud for ground remove
             * @param[out] objects output objects
             */
            void classifyGrPro(const PointCloudConstPtr in_cloud_ptr,PointCloudPtr obstacle_cloud_ptr);
            /**
             * @brief get ground points
             * @param[in,out] ground_cloud_ptr ground point cloud of ground
             */
            void getClassifyProGroundPts(PointCloudPtr ground_cloud_ptr);

            void setClassifyGrProParams(const Range2D& range = Range2D(-50,50,-50,50));
            void initClassifyProModel(const std::string& str);

        protected:
            inline int ptx2grid(const float& val);
            inline int pty2grid(const float& val);
            inline int rowcol2grid(const int& row,const int& col);
            inline bool isNanPt(const PointT& pt);
            inline float pt2range(const PointT& pt);
            bool isReasonableRange2D(const Range2D& range);
            bool init_;
            Range2D range_;
            float grid_size_;
            int rows_,cols_;
            PointCloudPtr ground_cloud_ptr_;
        private:
            RoboLidarConfig lidar_config_;
        };
    }
}

#endif //ROBOSENSE_DETECTION_CLASSIFY_GR_PRO_H
